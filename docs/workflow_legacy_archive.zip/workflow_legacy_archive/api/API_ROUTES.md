# API Routes - Contrats et Endpoints Backend

> **Code-Doc Context** – Blueprint Flask `routes/api_routes.py` avec 17 endpoints critiques, décorateurs `@measure_api` pour instrumentation PerformanceService, et tokens de sécurité pour workers internes.

---

## Purpose & System Role

### Objectif
Documentation complète des contrats API du backend Flask, incluant payloads, validations, codes d'erreur et hooks de performance. Chaque endpoint suit le pattern "thin controller → service layer" avec instrumentation automatique.

### Rôle dans l'Architecture
- **Position** : Blueprint `api_bp` dans `routes/api_routes.py`
- **Prérequis** : Services injectés (MonitoringService, WorkflowService, etc.)
- **Sortie** : Réponses JSON structurées avec métriques PerformanceService
- **Dépendances** : Config sécurité, services métier, logging structuré

---

## Architecture & Patterns

### Décorateur `@measure_api`
```python
@api_bp.route('/example')
@measure_api('/api/example')
def example_endpoint():
    """Automatically records response time and status code via PerformanceService"""
```

### Sécurité
- **Workers internes** : `@require_internal_worker_token` pour endpoints sensibles
- **Render register** : `@require_render_register_token` pour inscription Render
- **Validation** : Input parsing avec `request.get_json(silent=True)`

### Pattern Thin Controller
```python
# Standard pattern
try:
    # 1. Validate input
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "JSON required"}), 400
    
    # 2. Call service layer
    result = ServiceClass.process(data)
    
    # 3. Return structured response
    return jsonify(result.serialize()), 200
except Exception as e:
    logger.error(f"Endpoint error: {e}", exc_info=True)
    return jsonify({"error": "Internal error"}), 500
```

---

## Endpoints Catalog

### System Monitoring

#### `/api/system_monitor` (GET)
```json
// Response
{
    "cpu_percent": 45.2,
    "memory": {
        "percent": 67.8,
        "used_gb": 5.4,
        "total_gb": 8.0
    },
    "gpu": {
        "available": true,
        "name": "NVIDIA GTX 1650",
        "memory_used_mb": 1024,
        "memory_total_mb": 4096
    }
}
```
- **Service** : `MonitoringService.get_system_status()`
- **Codes** : 200 (success), 500 (server error)

#### `/api/system/diagnostics` (GET)
```json
// Response
{
    "python": {"version": "3.10.12", "implementation": "CPython"},
    "ffmpeg": {"version": "4.4.0"},
    "gpu": {"available": true, "name": "NVIDIA GTX 1650"},
    "config_flags": {
        "STEP5_ENABLE_GPU": "1",
        "TRACKING_CPU_WORKERS": "15"
    },
    "timestamp": "2026-02-04T16:20:00Z"
}
```
- **Service** : `MonitoringService.get_environment_diagnostics()`
- **Codes** : 200 (success), 500 (server error)

### Step Management

#### `/api/step_status/<step_key>` (GET)
```json
// Response
{
    "step_key": "step5",
    "status": "running",
    "progress": 45.5,
    "current_operation": "Processing frame 1234/3000",
    "logs": ["Frame 1234 processed", "Face detected: 2 objects"],
    "timestamp": "2026-02-04T16:20:00Z"
}
```
- **Service** : `WorkflowService.get_step_status(step_key)`
- **Validation** : step_key valide dans WorkflowCommandsConfig
- **Codes** : 200 (success), 404 (invalid step), 500 (server error)

#### `/api/csv_monitor_status` (GET)
```json
// Response
{
    "enabled": true,
    "last_check": "2026-02-04T16:15:00Z",
    "urls_processed": 23,
    "downloads_active": 2,
    "webhook_status": "connected"
}
```
- **Service** : `WorkflowService.get_csv_monitor_status()`
- **Codes** : 200 (success), 500 (server error)

### Performance & Metrics

#### `/api/performance/metrics` (GET)
```json
// Response
{
    "api_response_times": {
        "/api/system_monitor": {"avg_ms": 12.5, "count": 145},
        "/api/step_status": {"avg_ms": 8.3, "count": 89}
    },
    "system_metrics": {
        "cpu_avg": 42.1,
        "memory_avg": 65.7
    },
    "timestamp": "2026-02-04T16:20:00Z"
}
```
- **Service** : `PerformanceService.get_metrics()`
- **Codes** : 200 (success), 500 (server error)

#### `/api/performance/reset` (POST)
```json
// Response
{
    "status": "success",
    "message": "Performance metrics reset",
    "timestamp": "2026-02-04T16:20:00Z"
}
```
- **Service** : `PerformanceService.reset_metrics()`
- **Codes** : 200 (success), 500 (server error)

### Cache Management

#### `/api/cache/stats` (GET)
```json
// Response
{
    "total_entries": 156,
    "cache_size_mb": 23.4,
    "hit_rate": 0.87,
    "oldest_entry": "2026-02-03T10:15:00Z",
    "newest_entry": "2026-02-04T16:20:00Z"
}
```
- **Service** : `CacheService.get_stats()`
- **Codes** : 200 (success), 500 (server error)

#### `/api/cache/search` (GET)
```json
// Query params: ?q=video_stem&limit=10
// Response
{
    "results": [
        {
            "key": "video1_tracking",
            "path": "/cache/video1_tracking.json",
            "size_mb": 2.3,
            "created": "2026-02-04T15:30:00Z"
        }
    ],
    "total_count": 1
}
```
- **Service** : `CacheService.search(query, limit)`
- **Validation** : query string requis, limit ≤ 100
- **Codes** : 200 (success), 400 (invalid params), 500 (server error)

#### `/api/cache/list_today` (GET)
```json
// Response
{
    "folders": [
        {
            "name": "cache_001",
            "path": "/cache/cache_001",
            "created": "2026-02-04T08:00:00Z",
            "size_mb": 45.6
        }
    ],
    "total_count": 1
}
```
- **Service** : `CacheService.list_today_folders()`
- **Codes** : 200 (success), 500 (server error)

#### `/api/cache/open` (POST)
```json
// Request
{
    "folder_name": "cache_001"
}
// Response
{
    "success": true,
    "message": "Cache folder opened in file explorer"
}
```
- **Service** : `FilesystemService.open_path_in_explorer()`
- **Validation** : folder_name existe dans cache du jour
- **Codes** : 200 (success), 404 (folder not found), 500 (server error)

#### `/api/cache/clear` (POST)
```json
// Request
{
    "older_than_hours": 24,
    "dry_run": false
}
// Response
{
    "success": true,
    "folders_cleared": 5,
    "space_freed_mb": 234.5
}
```
- **Service** : `CacheService.clear_old_folders()`
- **Validation** : older_than_hours ≥ 1
- **Codes** : 200 (success), 400 (invalid params), 500 (server error)

### CSV Downloads & Monitoring

#### `/api/csv_downloads_status` (GET)
```json
// Response
{
    "enabled": true,
    "webhook_url": "https://webhook.kidpixel.fr/data/webhook_links.json",
    "last_sync": "2026-02-04T16:15:00Z",
    "total_urls": 156,
    "pending_downloads": 3,
    "failed_downloads": 0
}
```
- **Service** : `CSVService.get_download_status()`
- **Codes** : 200 (success), 500 (server error)

#### `/api/stats/dashboard` (GET)
```json
// Response
{
    "projects_total": 12,
    "videos_processed": 45,
    "avg_processing_time_min": 23.5,
    "success_rate": 0.96,
    "last_updated": "2026-02-04T16:20:00Z"
}
```
- **Service** : `VisualizationService.get_dashboard_stats()`
- **Codes** : 200 (success), 500 (server error)

#### `/api/stats/history` (GET)
```json
// Query params: ?days=7&metric=processing_time
// Response
{
    "metric": "processing_time",
    "data": [
        {"date": "2026-02-04", "value": 23.5},
        {"date": "2026-02-03", "value": 25.1}
    ],
    "unit": "minutes"
}
```
- **Service** : `VisualizationService.get_historical_stats()`
- **Validation** : days ≤ 30, metric valide
- **Codes** : 200 (success), 400 (invalid params), 500 (server error)

### Visualization

#### `/api/visualization/projects` (GET)
```json
// Response
{
    "projects": [
        {
            "name": "project_camille_001",
            "path": "/projets_extraits/project_camille_001",
            "videos": 3,
            "last_modified": "2026-02-04T14:30:00Z",
            "status": "completed"
        }
    ],
    "total_count": 1
}
```
- **Service** : `VisualizationService.get_available_projects()`
- **Codes** : 200 (success), 500 (server error)

### STEP4 - Lemonfox Audio Analysis

#### `/api/step4/lemonfox_audio` (POST)
```json
// Request
{
    "project_name": "project_camille_001",
    "video_name": "video1.mp4",
    "language": "fr",
    "prompt": "Interview analysis",
    "speaker_labels": true,
    "min_speakers": 1,
    "max_speakers": 3,
    "timestamp_granularities": ["word"],
    "eu_processing": true
}
// Response (success)
{
    "status": "success",
    "output_path": "/projets_extraits/project_camille_001/docs/video1_audio.json",
    "fps": 25.0,
    "total_frames": 1500
}
// Response (error)
{
    "status": "error",
    "error": "Project not found: project_camille_001"
}
```
- **Service** : `LemonfoxAudioService.process_video_with_lemonfox()`
- **Validation** : project_name et video_name requis, types valides
- **Codes** : 200 (success), 400 (invalid params), 404 (not found), 502 (Lemonfox API error), 500 (server error)

### Internal Workers

#### `/api/ping` (GET) - Worker Token Required
```json
// Response
{
    "status": "pong",
    "worker_type": "ubuntu_new",
    "timestamp": "2026-02-04T16:20:00Z"
}
```
- **Sécurité** : `@require_internal_worker_token`
- **Usage** : Health check pour workers internes

#### `/api/get_remote_status_summary` (GET) - Worker Token Required
```json
// Response
{
    "steps": {
        "step1": {"status": "completed", "progress": 100},
        "step5": {"status": "running", "progress": 45}
    },
    "system": {
        "cpu_percent": 42.1,
        "memory_percent": 65.7
    },
    "timestamp": "2026-02-04T16:20:00Z"
}
```
- **Sécurité** : `@require_internal_worker_token`
- **Service** : `WorkflowService.get_remote_status_summary()`

#### `/api/cache/clear` (POST)
```json
// Request
{
    "older_than_hours": 24,
    "dry_run": false
}
// Response
{
    "success": true,
    "folders_cleared": 5,
    "space_freed_mb": 234.5
}
```
- **Service** : `CacheService.clear_old_folders()`
- **Validation** : older_than_hours ≥ 1
- **Codes** : 200 (success), 400 (invalid params), 500 (server error)

#### `/api/cache/open` (POST)
```json
// Request
{
    "folder_name": "cache_001",
    "select_parent": false
}
// Response
{
    "success": true,
    "message": "Cache folder opened in file explorer"
}
```
- **Service** : `FilesystemService.open_path_in_explorer()`
- **Sécurité** : Headless guard (`DISABLE_EXPLORER_OPEN`), validation path
- **Codes** : 200 (success), 400 (invalid params), 404 (folder not found), 500 (server error)

#### `/api/register_render_worker` (POST) - Render Register Token Required
```json
// Request
{
    "worker_id": "render_worker_001",
    "capabilities": ["step2", "step5"],
    "max_concurrent_jobs": 2
}
// Response
{
    "status": "registered",
    "worker_id": "render_worker_001",
    "registered_at": "2026-02-04T16:20:00Z"
}
```
- **Sécurité** : `@require_render_register_token`
- **Service** : `WorkflowService.register_render_worker()`
- **Usage** : Registration idempotent for Render workers
- **Codes** : 200 (success), 400 (invalid params), 401 (unauthorized), 500 (server error)

---

## Error Handling Patterns

### Standard Error Response
```json
{
    "error": "Human-readable error message",
    "timestamp": "2026-02-04T16:20:00Z"
}
```

### Common Status Codes
- **200** : Success
- **400** : Invalid input parameters
- **404** : Resource not found
- **401** : Authentication/authorization failed
- **500** : Internal server error
- **502** : Upstream service error (ex: Lemonfox API)

### Validation Errors
```json
{
    "error": "Validation failed",
    "field": "project_name",
    "message": "project_name is required and must be non-empty"
}
```

---

## Performance Instrumentation

### Automatic Metrics
Tous les endpoints avec `@measure_api` enregistrent automatiquement :
- **Response time** : Temps de réponse en ms
- **Status code** : Code HTTP retourné
- **Endpoint name** : Nom logique pour agrégation

### Custom Metrics
```python
# Dans les services
PerformanceService.record_api_response_time(
    endpoint_name, elapsed_ms, status_code
)
```

### Monitoring Dashboard
Les métriques sont consultables via :
- `/api/performance/metrics` (API)
- Interface frontend Monitoring (si disponible)

---

## Sécurité & Tokens

### Internal Worker Token
```python
# Validation dans @require_internal_worker_token
token = request.headers.get('X-Internal-Worker-Token')
if token != INTERNAL_WORKER_COMMS_TOKEN:
    return jsonify({"error": "Unauthorized"}), 401
```

### Render Register Token
```python
# Validation pour inscription Render
token = request.headers.get('X-Render-Register-Token')
if token != RENDER_REGISTER_TOKEN:
    return jsonify({"error": "Unauthorized"}), 401
```

---

## Scripts & Workflows Déclenchés

### Mapping Endpoints → Scripts
| Endpoint | Script/Workflow | Environment | Notes |
|----------|-----------------|-------------|-------|
| `/api/step4/lemonfox_audio` | `workflow_scripts/step4/run_audio_analysis.py` | `audio_env` | Via LemonfoxAudioService |
| `/api/step_status/<step_key>` | Scripts STEP1-8 via WorkflowCommandsConfig | Variable | Status monitoring |
| `/api/cache/*` | Cache management scripts | `env` | Filesystem operations |

### Workflow Commands Integration
```python
# Les commandes sont définies dans WorkflowCommandsConfig
config = WorkflowCommandsConfig()
step_config = config.get_step_config('step4')
# step_config['command'], step_config['cwd'], etc.
```

---

## Testing & Validation

### Tests Unitaires
```python
# Exemple de test endpoint
def test_system_monitor_endpoint(client):
    response = client.get('/api/system_monitor')
    assert response.status_code == 200
    data = response.get_json()
    assert 'cpu_percent' in data
    assert 'memory' in data
```

### Tests d'Intégration
- Validation payloads complets
- Tests tokens de sécurité
- Tests instrumentation PerformanceService
- Tests erreurs upstream (Lemonfox API)

---

## Documentation Croisée

- [Architecture Complète](../core/ARCHITECTURE_COMPLETE_FR.md) : Vue d'ensemble système
- [WorkflowService](../features/WORKFLOW_SERVICE.md) : Orchestrateur central
- [Lemonfox Audio Service](../features/LEMONFOX_AUDIO_SERVICE.md) : Service STEP4
- [Performance Service](../features/VISUALIZATION_SERVICE.md) : Métriques et monitoring
- [Security Configuration](../core/GUIDE_DEMARRAGE_RAPIDE.md#sécurité) : Tokens et configuration

---

## Évolutions Planifiées

### Court Terme
- Ajout endpoints STEP5 (tracking status)
- Pagination pour listes longues (projects, cache)
- Rate limiting pour endpoints publics

### Moyen Terme
- WebSocket pour monitoring temps réel
- Bulk operations (multiple steps)
- Advanced filtering (dates, statuts)

---

*Generated with Code-Doc protocol – see audit metrics in ../complexity/COMPLEXITY_HOTSPOTS.md*
