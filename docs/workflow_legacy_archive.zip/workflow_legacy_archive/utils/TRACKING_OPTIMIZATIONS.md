# Utils Tracking Optimizations - Performance et Gestion du Tracking

> **Code-Doc Context** – Utilitaires critiques pour l'optimisation du tracking avec complexité radon E sur `apply_tracking_and_management` (230 lignes) et D sur `_filter_blendshapes_for_export`. Centralise le tuning blendshapes, le cycle de vie des objets et les algorithmes KDTree.

---

## Purpose & System Role

### Objectif
`utils/tracking_optimizations.py` fournit des utilitaires optimisés pour la gestion du cycle de vie des objets trackés, le filtrage des blendshapes et les algorithmes de matching spatial. Ces fonctions sont utilisées par les workers STEP5 pour garantir des performances temps réel.

### Rôle dans l'Architecture
- **Position** : Utilitaire partagé par tous les workers STEP5
- **Prérequis** : NumPy, SciPy, variables d'environnement STEP5
- **Sortie** : Objets trackés optimisés, blendshapes filtrés, IDs uniques
- **Dépendances** : Algorithme KDTree (SciPy), configuration blendshapes

---

## Architecture & Complexité

### Points Critiques (Score E/D)

#### `apply_tracking_and_management()` (Score E)
- **Complexité** : 230 lignes, gestion complète cycle de vie tracking
- **Défis** : Algorithmes KDTree, matching spatial, gestion mémoire
- **Impact** : Performance critique pour tous les moteurs de tracking

#### `_filter_blendshapes_for_export()` (Score D)
- **Complexité** : Filtrage intelligent blendshapes par profil
- **Défis** : Gestion profils multiples, validation entrées
- **Impact** : Réduction taille JSON (-95%) avec préservation fonctionnelle

---

## Fonctions Principales

### 1. Filtrage Blendshapes

#### `_filter_blendshapes_for_export(blendshapes)`
```python
# Profil configuré via STEP5_BLENDSHAPES_PROFILE
profile = os.environ.get("STEP5_BLENDSHAPES_PROFILE", "full").strip().lower()

# Profils disponibles
- "full" : Export complet (défaut)
- "none" : Aucun blendshape
- "mouth" : Uniquement bouche/mâchoire (+ langue optionnelle)
- "mediapipe" : Compatibilité MediaPipe (sans tongueOut)
- "custom" : Keys personnalisées via STEP5_BLENDSHAPES_EXPORT_KEYS
```

**Variables d'Environnement** :
```bash
STEP5_BLENDSHAPES_PROFILE=full          # mouth, none, mediapipe, custom
STEP5_BLENDSHAPES_INCLUDE_TONGUE=1     # Pour profil "mouth"
STEP5_BLENDSHAPES_EXPORT_KEYS=eyeBlink,eyeSquint  # Profil "custom"
```

**Impact Performance** :
- Réduction jusqu'à 95% de la taille JSON
- Préservation des blendshapes critiques pour l'animation
- Compatible avec tous les moteurs de tracking

### 2. Gestion IDs Uniques

#### `get_next_id(counter_ref, prefix="obj_")`
```python
counter = {"value": 0}
obj_id = get_next_id(counter, "face_")
# Résultat : "face_1", "face_2", ...
```

**Utilisation** :
- Gération d'IDs uniques pour objets trackés
- Préfixes configurables par type d'objet
- Thread-safe avec référence partagée

### 3. Cycle de Vie Tracking (Score E)

#### `apply_tracking_and_management()`
**Signature complète** :
```python
def apply_tracking_and_management(
    active_objects: Dict[str, Dict],
    current_detections: List[Dict],
    next_id_counter: Dict[str, int],
    distance_threshold: float,
    frames_unseen_to_deregister: int,
    speaking_detection_jaw_open_threshold: float = 0.08,
    enhanced_speaking_detector: Optional[Any] = None,
    current_frame_num: Optional[int] = None,
) -> Tuple[Dict[str, Dict], List[Dict]]:
```

**Phases d'Exécution** :

##### Phase 1 : Incrémentation Frames Unseen
```python
# Marquer tous les objets actifs comme non vus cette frame
for obj_id in active_objects:
    active_objects[obj_id]["frames_unseen"] += 1
```

##### Phase 2 : Matching Spatial (KDTree)
```python
# Construction KDTree pour recherche efficace
active_obj_ids = list(active_objects.keys())
tracked_centroids = np.array([obj["centroid"] for obj in active_objects.values()])
detection_centroids = np.array([det["centroid"] for det in current_detections])

kdtree = KDTree(tracked_centroids)
distances, indices = kdtree.query(detection_centroids, k=1)
```

##### Phase 3 : Appariement Optimisé
```python
# Algorithmes de matching avec contraintes
potential_matches = sorted(zip(distances, indices, range(len(current_detections))))

for dist, tracked_idx, det_idx in potential_matches:
    if dist > distance_threshold:  # Seuil distance
        continue
    if det_idx in matched_detection_indices:  # Déjà utilisé
        continue
    if tracked_idx in matched_tracked_indices:  # Déjà apparié
        continue
    
    # Appariement réussi
    obj_id = active_obj_ids[tracked_idx]
    # Mise à jour position et métadonnées
```

##### Phase 4 : Création Nouveaux Objets
```python
# Pour les détections non appariées
for det_idx in range(len(current_detections)):
    if det_idx not in matched_detection_indices:
        new_id = get_next_id(next_id_counter, "obj_")
        active_objects[new_id] = {
            "centroid": current_detections[det_idx]["centroid"],
            "frames_unseen": 0,
            "first_seen": current_frame_num,
            # ... autres métadonnées
        }
```

##### Phase 5 : Nettoyage Objets Orphelins
```python
# Supprimer les objets non vus depuis trop longtemps
to_remove = [
    obj_id for obj_id, obj_data in active_objects.items()
    if obj_data["frames_unseen"] > frames_unseen_to_deregister
]

for obj_id in to_remove:
    del active_objects[obj_id]
```

---

## Performance & Optimisations

### Algorithmes KDTree
- **Complexité** : O(log n) pour recherche au lieu de O(n²) naïf
- **Avantages** : Matching spatial efficace pour 1000+ détections
- **Implémentation** : SciPy KDTree avec requêtes optimisées

### Memory Management
```python
# Éviter les copies inutiles
tracked_centroids = np.array([obj["centroid"] for obj in active_objects.values()])
# Références directes aux objets existants
active_objects[obj_id].update(new_data)
```

### Thresholds Tuning
```python
# Variables configurables
distance_threshold = 50.0  # pixels
frames_unseen_to_deregister = 10  # frames
speaking_detection_jaw_open_threshold = 0.08  # normalisé 0-1
```

---

## Configuration & Variables

### Variables d'Environnement
```bash
# Blendshapes
STEP5_BLENDSHAPES_PROFILE=full
STEP5_BLENDSHAPES_INCLUDE_TONGUE=1
STEP5_BLENDSHAPES_EXPORT_KEYS=eyeBlink,eyeSquint,jawOpen

# Tracking (utilisé par les workers)
TRACKING_DISTANCE_THRESHOLD=50.0
TRACKING_FRAMES_UNSEEN_TO_DEREGISTER=10
TRACKING_SPEAKING_JAW_THRESHOLD=0.08
```

### Patterns d'Utilisation
```python
# Dans workers STEP5
from utils.tracking_optimizations import (
    apply_tracking_and_management,
    _filter_blendshapes_for_export,
    get_next_id
)

# Initialisation
counter = {"value": 0}
active_objects = {}

# Pour chaque frame
active_objects, new_detections = apply_tracking_and_management(
    active_objects=active_objects,
    current_detections=frame_detections,
    next_id_counter=counter,
    distance_threshold=50.0,
    frames_unseen_to_deregister=10,
    current_frame_num=frame_num
)

# Filtrage blendshapes avant export
filtered_blendshapes = _filter_blendshapes_for_export(blendshapes)
```

---

## Tests & Validation

### Tests Unitaires
```python
def test_blendshapes_filtering():
    blendshapes = {"eyeBlink": 0.5, "mouthOpen": 0.8, "tongueOut": 0.3}
    
    # Profil "mouth"
    os.environ["STEP5_BLENDSHAPES_PROFILE"] = "mouth"
    result = _filter_blendshapes_for_export(blendshapes)
    assert "mouthOpen" in result
    assert "eyeBlink" not in result

def test_tracking_lifecycle():
    active_objects = {}
    counter = {"value": 0}
    detections = [{"centroid": [100, 100]}]
    
    updated, new = apply_tracking_and_management(
        active_objects, detections, counter, 50.0, 10
    )
    
    assert len(updated) == 1
    assert "obj_1" in updated
```

### Benchmarks Performance
- **KDTree vs Naïf** : 100x plus rapide pour 1000+ détections
- **Blendshapes Filtering** : Réduction 95% taille JSON
- **Memory Usage** : Constant O(n) avec n = objets actifs

---

## Debugging & Monitoring

### Logs Structurés
```python
# Dans apply_tracking_and_management
logger.debug(f"[TRACKING] Frame {current_frame_num}: "
            f"Active={len(active_objects)}, "
            f"Detections={len(current_detections)}, "
            f"Matches={len(matches)}")

logger.info(f"[TRACKING] Created {len(new_objects)} objects, "
           f"Removed {len(removed_objects)} objects")
```

### Metrics Clés
- **Matching Rate** : % détections appariées avec succès
- **Object Lifecycle** : Durée de vie moyenne des objets trackés
- **Memory Usage** : Nombre d'objets actifs en mémoire

---

## Intégration STEP5

### Utilisation dans Workers
```python
# workflow_scripts/step5/process_video_worker.py
from utils.tracking_optimizations import apply_tracking_and_management

# Boucle de traitement frame par frame
for frame_num, frame in enumerate(video_frames):
    detections = engine.detect(frame, frame_num)
    
    # Filtrage blendshapes
    for det in detections:
        if 'blendshapes' in det:
            det['blendshapes'] = _filter_blendshapes_for_export(
                det['blendshapes']
            )
    
    # Gestion cycle de vie tracking
    active_objects, new_objects = apply_tracking_and_management(
        active_objects=active_objects,
        current_detections=detections,
        next_id_counter=id_counter,
        distance_threshold=50.0,
        frames_unseen_to_deregister=10,
        current_frame_num=frame_num
    )
    
    # Export JSON avec objets trackés
    frame_data = {
        "frame": frame_num,
        "tracked_objects": list(active_objects.values())
    }
```

---

## Documentation Croisée

- [STEP5 Suivi Vidéo](../pipeline/STEP5_SUIVI_VIDEO.md) : Pipeline global
- [STEP5 Face Engines](../pipeline/STEP5_FACE_ENGINES.md) : Moteurs de détection
- [Complexity Hotspots](../complexity/COMPLEXITY_HOTSPOTS.md) : Métriques radon
- [Architecture Complète](../core/ARCHITECTURE_COMPLETE_FR.md) : Vue d'ensemble

---

## Évolutions Planifiées

### Court Terme
- Ajout profils blendshapes pré-configurés
- Optimisation KDTree pour GPU (cuPy)

### Moyen Terme
- Algorithmes de tracking prédictifs
- Support multi-caméras synchronisées

---

*Generated with Code-Doc protocol – see audit metrics in ../complexity/COMPLEXITY_HOTSPOTS.md*
